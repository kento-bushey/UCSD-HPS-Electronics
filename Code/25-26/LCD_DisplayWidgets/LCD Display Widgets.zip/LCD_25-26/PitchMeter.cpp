#include "PitchMeter.h"

void PitchMeter::InitPitchMeter(float dist, float radius_, float fov_, float yScale_){
  radius = radius_;
  tfov2 = tan(radians(fov_)/2.0);
  yScale = yScale_;
  distToCenter = dist;
}

void PitchMeter::Draw(int pitch, uint16_t color1, uint16_t color2, uint16_t color3) {
    //Boudning box
    //screen->drawRect(pos.x,pos.y,w,h,color1);
    screen->drawCircle(pos.x+w*0.5,pos.y+h*0.5,w*0.4, color1);
    //loop over 30 degrees of pitch:
    for(int i = pitch-20; i<=pitch+20; i++){
    float z = distToCenter-radius*cos( radians( yScale*abs(static_cast<float>(i-pitch)) ) );
      //println(z);
      float y = radius*(sin( radians( yScale*static_cast<float>(i-pitch) ) ));
      
     
     float wh = w*0.5f/(z*tfov2) - w*0.5;
     float yh = 0.5*h*y/(z*tfov2);
    
     
     
    if(abs(i)%5==0){
      
        if(abs(i)%10==0){
           //if(i<0)stroke(100,100,255);
           //else stroke(100,255,100);
           //if(i==0){strokeWeight(4); stroke(255,255,0);}
           //if(i==pitch){strokeWeight(4); stroke(255,0,0);}
           screen->drawLine(
                pos.x-wh + w*0.5f, pos.y+yh + h*0.5f,
                pos.x+wh + w*0.5f, pos.y+yh + h*0.5f, color2
           );

           float textY = constrain(pos.y+yh+h*0.5f-5, pos.y,pos.y+h-10);
           screen->drawChar(pos.x+w*0.5f+10,textY,'0' + (char)(i%10), color1, 0, abs(sin( radians( yScale*static_cast<float>(i-pitch) ) ))<0.35?2:1);
           screen->drawChar(pos.x+w*0.5f-5,textY,'0' + (char)(abs(i)/10), color1, 0, abs(sin( radians( yScale*static_cast<float>(i-pitch) )) )<0.35?2:1);
           screen->drawChar(pos.x+w*0.5f-20,textY,i<0?'-':(i>0?'+':' '), color1, 0, abs(sin( radians( yScale*static_cast<float>(i-pitch) ) ))<0.35?2:1);
           /*TODO::
            * 
           textSize(30);
           text(i,width/2+1.2*wh,height/2+yh+10);
           strokeWeight(2);
           */
        }else{
           //stroke(255);
           //if(i==0){strokeWeight(4); stroke(255,255,0);}
           //if(i==pitch){strokeWeight(4); stroke(255,0,0);}
           screen->drawLine(
                pos.x-wh*0.5f + w*0.5f, pos.y+yh + h*0.5f,
                pos.x+wh*0.5f + w*0.5f, pos.y+yh + h*0.5f, color3
           );
/*
           void setCursor(int16_t x0, int16_t y0); 
           void setTextColor(uint16_t color); 
           void setTextColor(uint16_t color, 
           uint16_t backgroundcolor); 
           void setTextSize(uint8_t size); 
           void setTextWrap(boolean w);
           */
           /*TODO::
            * textSize(20);
           text(i,width/2+wh*0.5f-30,height/2+yh+5);
           strokeWeight(2);
           */
        }
      }
      else{
          //stroke(100);
          /*if(i%2==0){screen->drawLine(
                pos.x-wh*0.1f + w*0.5f, pos.y+yh + h*0.5f,
                pos.x+wh*0.1f + w*0.5f, pos.y+yh + h*0.5f, color3
           );*/
          //}
     }

     screen->drawLine(pos.x,pos.y+h*0.5f,pos.x+w,pos.y+0.5*h,color1);
     
  
  }
  previousValue = pitch;
}
